import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;

import com.jit.emotionfinder.textanalysis.EmotionalState;
import com.jit.emotionfinder.textanalysis.Empathyscope;
import com.jit.emotionfinder.util.CategorizeUtility;
import com.jit.emotionfinder.util.DirectoryUtility;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.labels.PieSectionLabelGenerator;
import org.jfree.chart.labels.StandardPieSectionLabelGenerator;
import org.jfree.chart.plot.PiePlot;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;

//This is the UI module which uses the proposed emotion finder algorithm to extract emotion from text file or files
@SuppressWarnings("serial")
public class TextAnalyserModule extends JFrame
{

	private JPanel contentPane;
	private JTextField filePath = new JTextField();
	private JTextField filePath2;
	final JLabel impression = new JLabel("");
	JLabel dirErrMsg = new JLabel("");
	JLabel filErrMsg = new JLabel("");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) 
	{
		EventQueue.invokeLater(new Runnable() 
		{
			public void run() 
			{
				try
				{
					TextAnalyserModule frame = new TextAnalyserModule();
					frame.setVisible(true);
				}
				catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TextAnalyserModule() 
	{
		setBackground(new Color(153, 204, 255));
		
		setTitle("Text Analyser(Emotion Finder)");
		
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		setBounds(100, 100, 893, 627);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		//Report column
		JLabel lblReport = new JLabel("Report :");
		lblReport.setHorizontalAlignment(SwingConstants.LEFT);
		lblReport.setForeground(new Color(50, 205, 50));
		lblReport.setFont(new Font("Microsoft Sans Serif", Font.BOLD, 20));
		lblReport.setBackground(new Color(50, 205, 50));
		lblReport.setBounds(606, 203, 147, 28);
		contentPane.add(lblReport);
		impression.setIcon(null);
		
		
				impression.setForeground(new Color(255, 0, 0));
				impression.setBackground(new Color(255, 0, 0));
				impression.setHorizontalAlignment(SwingConstants.LEFT);
				impression.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 20));
				impression.setBounds(706, 203, 147, 28);
				contentPane.add(impression);

		JLabel lblHappinessWeight = new JLabel("1) Happiness :");
		
		lblHappinessWeight.setFont(new Font("Microsoft YaHei UI", Font.BOLD, 14));
		lblHappinessWeight.setBounds(606, 260, 115, 20);
		
		contentPane.add(lblHappinessWeight);
		
		final JLabel happinessWeight = new JLabel("");
		happinessWeight.setFont(new Font("Segoe UI Black", Font.BOLD, 14));
		happinessWeight.setBounds(720, 260, 115, 20);
		
		contentPane.add(happinessWeight);
		
				JLabel lblSadnessWeight = new JLabel("2) Sadness :");
				lblSadnessWeight.setFont(new Font("Microsoft YaHei UI", Font.BOLD, 14));
				lblSadnessWeight.setBounds(606, 291, 115, 20);
				
				contentPane.add(lblSadnessWeight);
				
						final JLabel sadnessWeight = new JLabel("");
						sadnessWeight.setFont(new Font("Segoe UI Black", Font.BOLD, 14));
						sadnessWeight.setBounds(720, 291, 115, 20);
						
						contentPane.add(sadnessWeight);
						
								JLabel lblAngerWeight = new JLabel("3) Anger :");
								
								lblAngerWeight.setFont(new Font("Microsoft YaHei UI", Font.BOLD, 14));
								lblAngerWeight.setBounds(606, 322, 115, 20);
								
								contentPane.add(lblAngerWeight);
								
										final JLabel angerWeight = new JLabel("");
										angerWeight.setFont(new Font("Segoe UI Black", Font.BOLD, 14));
										angerWeight.setBounds(720, 322, 115, 20);
										
										contentPane.add(angerWeight);
										
												JLabel lblFearWeight = new JLabel("4) Fear :");
												
												lblFearWeight.setFont(new Font("Microsoft YaHei UI", Font.BOLD, 14));
												lblFearWeight.setBounds(606, 353, 115, 20);
												
												contentPane.add(lblFearWeight);
												
														final JLabel fearWeight = new JLabel("");
														fearWeight.setFont(new Font("Segoe UI Black", Font.BOLD, 14));
														fearWeight.setBounds(720, 353, 115, 20);
														
														contentPane.add(fearWeight);
														
																JLabel lblDisgustWeight = new JLabel("5) Disgust :");
																
																lblDisgustWeight.setFont(new Font("Microsoft YaHei UI", Font.BOLD, 14));
																lblDisgustWeight.setBounds(606, 384, 115, 20);
																
																contentPane.add(lblDisgustWeight);
																
																		final JLabel disgustWeight = new JLabel("");
																		disgustWeight.setFont(new Font("Segoe UI Black", Font.BOLD, 14));
																		disgustWeight.setBounds(720, 384, 115, 20);
																		
																		contentPane.add(disgustWeight);
																		
																				JLabel lblSurpriseWeight = new JLabel("6) Surprise :");
																				
																				lblSurpriseWeight.setFont(new Font("Microsoft YaHei UI", Font.BOLD, 14));
																				lblSurpriseWeight.setBounds(606, 415, 115, 20);
																				
																				contentPane.add(lblSurpriseWeight);
																				
																						final JLabel surpriseWeight = new JLabel("");
																						surpriseWeight.setFont(new Font("Segoe UI Black", Font.BOLD, 14));
																						surpriseWeight.setBounds(720, 415, 115, 20);
																						
																						contentPane.add(surpriseWeight);

		// report column end here
		

		// User UI space
		JLabel lblModuleName = new JLabel("Text Analyser");
		
		lblModuleName.setForeground(new Color(100, 149, 237));
		lblModuleName.setFont(new Font("Microsoft JhengHei", Font.BOLD, 24));
		lblModuleName.setHorizontalAlignment(SwingConstants.CENTER);
		lblModuleName.setBounds(0, 53, 877, 51);
		contentPane.add(lblModuleName);

		JLabel lblPleaseEnterThe = new JLabel("1) Live Text Analyser: Enter any english article to analyse.");
		
		lblPleaseEnterThe.setForeground(new Color(0, 0, 128));
		lblPleaseEnterThe.setBackground(Color.BLACK);
		lblPleaseEnterThe.setHorizontalAlignment(SwingConstants.LEFT);
		lblPleaseEnterThe.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 16));
		lblPleaseEnterThe.setBounds(34, 128, 513, 32);
		contentPane.add(lblPleaseEnterThe);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(35, 173, 525, 120);
		contentPane.add(scrollPane);
		
				final JTextPane inputText = new JTextPane();
				inputText.setFont(new Font("Microsoft JhengHei", Font.BOLD, 14));
				inputText.setText("Enter text here.\r\n");
				scrollPane.setViewportView(inputText);

		JButton btnNewButton = new JButton("ANALYSE"); // ANALYSE BUTTON1 FUNCTION
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {

			try {
				EmotionalState emotionalState = Empathyscope.feel(inputText.getText());
				happinessWeight.setText(String.valueOf(emotionalState.getHappinessWeight())+"%"+" ("+Empathyscope.temp1+") ");
				sadnessWeight.setText(String.valueOf(emotionalState.getSadnessWeight())+"%"+" ("+Empathyscope.temp2+") ");
				angerWeight.setText(String.valueOf(emotionalState.getAngerWeight())+"%"+" ("+Empathyscope.temp3+") ");
				fearWeight.setText(String.valueOf(emotionalState.getFearWeight())+"%"+" ("+Empathyscope.temp4+") ");
				disgustWeight.setText(String.valueOf(emotionalState.getDisgustWeight())+"%"+" ("+Empathyscope.temp5+") ");
				surpriseWeight.setText(String.valueOf(emotionalState.getSurpriseWeight())+"%"+" ("+Empathyscope.temp6+") ");
				String impr = CategorizeUtility.findCategory(emotionalState);
				impression.setText(impr);
				System.out.println("�nsv� overall impression:"+impr);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
			
		});
		
		btnNewButton.setForeground(new Color(0, 0, 0));
		btnNewButton.setBackground(new Color(255, 0, 0));
		btnNewButton.setBounds(471, 304, 89, 23);
		contentPane.add(btnNewButton);
				
						JLabel lblOrSelectOne = new JLabel("2) File Analyser: Enter the path of single .txt file to analyse.");
						lblOrSelectOne.setForeground(new Color(0, 0, 128));
						lblOrSelectOne.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 16));
						lblOrSelectOne.setBounds(34, 345, 497, 22);
						contentPane.add(lblOrSelectOne);
				
						filePath2 = new JTextField();
						filePath2.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 14));
						filePath2.setText("Insert text file here.");
						filePath2.setColumns(10);
						filePath2.setBounds(34, 378, 526, 26);
						contentPane.add(filePath2);
						
						final JFileChooser fileDialog2 = new JFileChooser();
						fileDialog2.setFileFilter(new FileNameExtensionFilter("TEXT FILES", "txt", "text"));
										
						JButton button = new JButton("Browse ...");
						button.setBackground(new Color(176, 224, 230));
						button.addActionListener(new ActionListener() // ANALYZE BUTTON2 Function
						{
							public void actionPerformed(ActionEvent e) 
							{

								int returnVal = fileDialog2.showOpenDialog(contentPane);
								if (returnVal == JFileChooser.APPROVE_OPTION) 
								{
									java.io.File file = fileDialog2.getSelectedFile();
									filePath2.setText(file.getPath());
								}
								else 
								{

								}

							}
						});
						button.setBounds(360, 415, 89, 25);
						contentPane.add(button);
				
						JButton btnAnalyse = new JButton("ANALYSE");
						btnAnalyse.addActionListener(new ActionListener() //ANALYZE BUTTON3 Function
						{
							public void actionPerformed(ActionEvent e) 
							{
								filErrMsg.setText("");
								String content = "";
								try 
								{
									File file = new File(filePath2.getText());
									if (!file.exists()) 
									{
										filErrMsg.setText("Error: The specified file doesn't exist");
									}
									else if (!file.getName().contains("txt")) 
									{
										filErrMsg.setText("Error: Please specify only .txt files");
									}
									BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream((file))));

									String line = "";
									while ((line = br.readLine()) != null) 
									{
										content += line;
									}
									br.close();

									try 
									{
										EmotionalState emotionalState = Empathyscope.feel(content);
										happinessWeight.setText(String.valueOf(emotionalState.getHappinessWeight())+"%"+" ("+Empathyscope.temp1+") ");
										sadnessWeight.setText(String.valueOf(emotionalState.getSadnessWeight())+"%"+" ("+Empathyscope.temp2+") ");
										angerWeight.setText(String.valueOf(emotionalState.getAngerWeight())+"%"+" ("+Empathyscope.temp3+") ");
										fearWeight.setText(String.valueOf(emotionalState.getFearWeight())+"%"+" ("+Empathyscope.temp4+") ");
										disgustWeight.setText(String.valueOf(emotionalState.getDisgustWeight())+"%"+" ("+Empathyscope.temp5+") ");
										surpriseWeight.setText(String.valueOf(emotionalState.getSurpriseWeight())+"%"+" ("+Empathyscope.temp6+") ");
										String impr = CategorizeUtility.findCategory(emotionalState);
										impression.setText(impr);
										System.out.println("�nsv� overall impression:"+impr);
									}
									catch (IOException e4) 
									{
										e4.printStackTrace();
									}

								}
								catch (Exception e2) 
								{
									e2.printStackTrace();
								}

							}
						});
						btnAnalyse.setBackground(Color.ORANGE);
						btnAnalyse.setBounds(471, 415, 89, 23);
						contentPane.add(btnAnalyse);
				
				filErrMsg.setForeground(Color.RED);
				filErrMsg.setBounds(34, 429, 376, 14);
				contentPane.add(filErrMsg);
		
				JLabel lblOrSelectAn = new JLabel(
						"3) Directory Analyser: Enter the path of multiple .txt files to analyse.");
				lblOrSelectAn.setForeground(new Color(0, 0, 128));
				lblOrSelectAn.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 16));
				lblOrSelectAn.setBounds(34, 454, 513, 23);
				contentPane.add(lblOrSelectAn);
		
		filePath.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 16));
		
		filePath.setText("Insert folder directory here.");

		filePath.setBounds(34, 488, 526, 26);
		contentPane.add(filePath);
		filePath.setColumns(10);

		final JFileChooser fileDialog = new JFileChooser();
		fileDialog.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

		JButton btnBrowse = new JButton("Browse ...");
		btnBrowse.setBackground(new Color(176, 224, 230));
		btnBrowse.addActionListener(new ActionListener() //BROWSE BUTTON FUNCTION
		{
			public void actionPerformed(ActionEvent arg0)
			{

				int returnVal = fileDialog.showOpenDialog(contentPane);
				if (returnVal == JFileChooser.APPROVE_OPTION) 
				{
					java.io.File file = fileDialog.getSelectedFile();
					filePath.setText(file.getPath());
				}
				else 
				{

				}

			}
		});
		btnBrowse.setBounds(360, 525, 89, 25);
		contentPane.add(btnBrowse);

		JButton btnAnalyze = new JButton("ANALYSE"); //ANALYSE BUTTON3 FUNCTION
		btnAnalyze.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) 
			{
				
				dirErrMsg.setText("");

				try 
				{
					File dir = new File(filePath.getText());
					if (!dir.exists()) 
					{
						dirErrMsg.setText("Error: Specified Directory doesn't exist");
					}
					final Map<String, EmotionalState> result = new HashMap<String, EmotionalState>();
					if (dir.isDirectory()) 
					{
						String content = "";
						for (String f : dir.list()) 
						{
							File fl = new File(dir.getAbsolutePath() + "\\" + f);
							BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(fl)));
							if (fl.getName().contains("txt")) 
							{
								String line = "";
								content = "";
								while ((line = br.readLine()) != null) 
								{
									content += line;
								}
								EmotionalState emotionalState = Empathyscope.feel(content);
								result.put(f, emotionalState);
							}
							br.close();

						}

						EventQueue.invokeLater(new Runnable() 
						{
							public void run()
							{
								try 
								{
									DirectoryUtility frame = new DirectoryUtility();
									Iterator<String> it = result.keySet().iterator();
									int countpositive = 0;
									int countnegative=0;
									int countneutral = 0;
									
									while (it.hasNext()) 
									{
										String filename = it.next();
										EmotionalState es = result.get(filename);
									
										//CategorizeUtility u = new CategorizeUtility();
										
										String category = CategorizeUtility.findCategory(es);
										if (category.equals("positive")) 
										{
											countpositive++;
											frame.positive.append(filename + "\n");
											frame.positive.append(" - Happiness:\t" + es.getHappinessWeight() + "\n");
											frame.positive.append(" - Sadness:\t" + es.getSadnessWeight() + "\n");
											frame.positive.append(" - Anger:\t" + es.getAngerWeight() + "\n");
											frame.positive.append(" - Disgust:\t" + es.getDisgustWeight() + "\n");
											frame.positive.append(" - Fear:\t" + es.getFearWeight() + "\n");
											frame.positive.append(" - Surprise:\t" + es.getSurpriseWeight() + "\n\n");
										}
										if (category.equals("negative")) 
										{
											countnegative++;
											frame.negative.append(filename + "\n");
											frame.negative.append(" - Happiness:\t" + es.getHappinessWeight() + "\n");
											frame.negative.append(" - Sadness:\t" + es.getSadnessWeight() + "\n");
											frame.negative.append(" - Anger:\t" + es.getAngerWeight() + "\n");
											frame.negative.append(" - Disgust:\t" + es.getDisgustWeight() + "\n");
											frame.negative.append(" - Fear:\t" + es.getFearWeight() + "\n");
											frame.negative.append(" - Surprise:\t" + es.getSurpriseWeight() + "\n\n");
										}
										if (category.equals("neutral")) 
										{
											countneutral++;
											frame.neutral.append(filename + "\n");
											frame.neutral.append(" - Happiness:\t" + es.getHappinessWeight() + "\n");
											frame.neutral.append(" - Sadness:\t" + es.getSadnessWeight() + "\n");
											frame.neutral.append(" - Anger:\t" + es.getAngerWeight() + "\n");
											frame.neutral.append(" - Disgust:\t" + es.getDisgustWeight() + "\n");
											frame.neutral.append(" - Fear:\t" + es.getFearWeight() + "\n");
											frame.neutral.append(" - Surprise:\t" + es.getSurpriseWeight() + "\n\n");
										}

									}
									
									frame.cpos.setText(String.valueOf(countpositive));
									frame.cneg.setText(String.valueOf(countnegative));
									frame.cneutral.setText(String.valueOf(countneutral));
									frame.setVisible(true);
									System.out.println("�nsv� positive files count:"+countpositive);
									System.out.println("�nsv� negative files count:"+countnegative);
									System.out.println("�nsv� neutral files count:"+countneutral);
								} 
								catch (Exception e) 
								{
									e.printStackTrace();
								}
							}
						});
					}
				}
				catch (Exception e2) 
				{
					e2.printStackTrace();
				}
			}
		});
		
		
		
		
		
		btnAnalyze.setBackground(Color.GREEN);
		btnAnalyze.setBounds(471, 525, 89, 23);
		contentPane.add(btnAnalyze);
		dirErrMsg.setForeground(Color.RED);
		dirErrMsg.setBounds(34, 546, 376, 14);
		contentPane.add(dirErrMsg);
		
		JButton btnPiChart = new JButton("Graphical Presentation");
		btnPiChart.addActionListener(new java.awt.event.ActionListener() 
		{
			
				public void actionPerformed(java.awt.event.ActionEvent evt) 
				{
					PiactionPerformed(evt);
				}
			
			
		});
		
		btnPiChart.setBounds(631, 464, 179, 68);
		contentPane.add(btnPiChart);
		// User UI space ends here
	}
	
	public void PiactionPerformed(java.awt.event.ActionEvent evt) 
	{
		JFrame f = new JFrame();
		f.getContentPane().add(createPiePanel());
		f.pack();
		f.setVisible(true);
		f.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);	
	}

	public static JPanel createPiePanel() 
	{
	JFreeChart pieChart = createPieChart(createPieDataset());
	return new ChartPanel(pieChart);
	}

	private static JFreeChart createPieChart(PieDataset dataset) {

		JFreeChart chart = ChartFactory.createPieChart("Emotion Analysis Chart", // chart
																					// title
				dataset, // data
				true, // include legend
				true, false);

		PiePlot plot = (PiePlot) chart.getPlot();
		plot.setSectionOutlinesVisible(false);
		plot.setNoDataMessage("No data available");
		PieSectionLabelGenerator gen = new StandardPieSectionLabelGenerator("{0}: {2}", new DecimalFormat("0"),
				new DecimalFormat("0%"));
		plot.setLabelGenerator(gen);

		return chart;

	}
	
	private static PieDataset createPieDataset() {
		DefaultPieDataset dataset = new DefaultPieDataset();
		dataset.setValue( "Happiness Weight" , new Double((double) Empathyscope.temp1));  
	      dataset.setValue( "Sadness Weight" , new Double((double)Empathyscope.temp2));   
	      dataset.setValue( "Anger Weight" , new Double((double) Empathyscope.temp3));   
	      dataset.setValue( "Fear Weight" , new Double((double) Empathyscope.temp4)); 
	      dataset.setValue( "Disgust Weight" , new Double((double) Empathyscope.temp5));  
	      dataset.setValue( "Surprise Weight" , new Double((double) Empathyscope.temp6));   
	      
	      return dataset; 
		
	}


}