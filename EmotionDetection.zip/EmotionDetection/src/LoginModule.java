import java.awt.CardLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;


import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EtchedBorder;

import com.jit.dao.UserDAO;
import javax.swing.ImageIcon;
import java.awt.Toolkit;
import javax.swing.JOptionPane;
import java.awt.Component;

//This is the UI component built from windows builder tool integrating both modules and restricting unauthorized access
@SuppressWarnings("serial")
public class LoginModule extends JFrame 
{

	private JPanel contentPane;
	private JTextField un_login;
	private JTextField un_reg;
	JPanel homePanel = new JPanel();
	JLabel welcomemsg = new JLabel("");
	private JPasswordField pwd_login;
	private JPasswordField pwd_reg;
	private Component frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args)
	{
		EventQueue.invokeLater(new Runnable() 
		{
			public void run() 
			{
				try
				{
					LoginModule frame = new LoginModule();
					frame.setVisible(true);
				} 
				catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * 
	 * @throws ParseException
	 */
	/**
	 * @throws ParseException
	 */
	public LoginModule() throws ParseException 
	{
		setIconImage(Toolkit.getDefaultToolkit().getImage(LoginModule.class.getResource("/logo.jpg")));
		setResizable(false);
		setTitle("Emotion Detector");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 653, 432);
		
		contentPane = new JPanel();
		contentPane.setForeground(Color.DARK_GRAY);
		contentPane.setBackground(Color.GRAY);
		contentPane.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.LIGHT_GRAY);
		panel_1.setBounds(39, 143, 541, 227);
		contentPane.add(panel_1);
		panel_1.setLayout(new CardLayout(0, 0));
		final JPanel LoginPanel = new JPanel();

		panel_1.add(LoginPanel, "name_47643771253691");
		LoginPanel.setLayout(null);

		JLabel lblUsername = new JLabel("Username");
		lblUsername.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 13));
		lblUsername.setBounds(21, 57, 72, 14);
		LoginPanel.add(lblUsername);

		un_login = new JTextField();
		un_login.setFont(new Font("Tahoma", Font.PLAIN, 13));
		un_login.setBounds(92, 54, 160, 20);
		LoginPanel.add(un_login);
		un_login.setColumns(10);
		
				pwd_login = new JPasswordField();
				pwd_login.setFont(new Font("Tahoma", Font.PLAIN, 15));
				pwd_login.setEchoChar('*');
				pwd_login.setBounds(92, 85, 160, 20);
				LoginPanel.add(pwd_login);

		JLabel lblPassword = new JLabel("Password");
		lblPassword.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 13));
		lblPassword.setBounds(21, 91, 72, 14);
		LoginPanel.add(lblPassword);
		
		final JLabel loginFail = new JLabel("");
		loginFail.setHorizontalAlignment(SwingConstants.CENTER);
		loginFail.setForeground(Color.RED);
		loginFail.setFont(new Font("Tahoma", Font.PLAIN, 10));

		JButton btnNewButton_1 = new JButton("LOGIN");
		btnNewButton_1.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 17));
		btnNewButton_1.addActionListener(new ActionListener() 
		{
				public void actionPerformed(ActionEvent arg0) 
				{
				String un = un_login.getText();
				@SuppressWarnings("deprecation")
				String pw = pwd_login.getText();
				if (un == null || un.trim().length() == 0 || pw == null || pw.trim().length() == 0) 
				  {
					loginFail.setText("Please enter your username and password");
					JOptionPane.showMessageDialog(frame,"Please enter your username and password","Login Error",JOptionPane.ERROR_MESSAGE);
				  } 
				else
				  {
					UserDAO dao = new UserDAO();
					try
					{
						if (dao.login(un, pw)) 
						{
							LoginPanel.setVisible(false);
							homePanel.setVisible(true);
							welcomemsg.setText("Welcome " + un);
							System.out.println(" success");
						}
						else
						{
							loginFail.setText("Invalid Credentials(Please Sign Up)");
							JOptionPane.showMessageDialog(frame,"Please check your username and password","Login Error",JOptionPane.ERROR_MESSAGE);
						}

					} 
					catch (Exception e) 
					{
						e.printStackTrace();
						loginFail.setText("<html>Something went wrong.<br/>" + e.getMessage() + "</html>");
						System.out.println(" System error");
					}

				  }

			}
		});
		btnNewButton_1.setBounds(21, 126, 231, 76);
		LoginPanel.add(btnNewButton_1);

		un_reg = new JTextField();
		un_reg.setFont(new Font("Tahoma", Font.PLAIN, 13));
		un_reg.setColumns(10);
		un_reg.setBounds(371, 54, 160, 20);
		LoginPanel.add(un_reg);

		JLabel label_1 = new JLabel("Password");
		label_1.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 13));
		label_1.setBounds(290, 91, 72, 14);
		LoginPanel.add(label_1);
		final JLabel regSuccess = new JLabel("");
		regSuccess.setHorizontalAlignment(SwingConstants.CENTER);
		regSuccess.setForeground(Color.RED);
		regSuccess.setFont(new Font("Tahoma", Font.PLAIN, 10));

		JButton btnRegister = new JButton("REGISTER");								//Register Button
		btnRegister.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 17));
		btnRegister.addActionListener(new ActionListener() 							//Register button action
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				String un = un_reg.getText();
				@SuppressWarnings("deprecation")
				String pw = pwd_reg.getText();
				if (un == null || un.trim().length() == 0 || pw == null || pw.trim().length() == 0) 
				{
					regSuccess.setText("Please enter a valid username and password");
					JOptionPane.showMessageDialog(frame,"Invalid Credentials","Account Create Error",JOptionPane.WARNING_MESSAGE);
				} 
				else 
				{
					UserDAO dao = new UserDAO();
					try 
					{
						dao.register(un, pw);
						regSuccess.setText("Successfully created an account. You can login now");
						JOptionPane.showMessageDialog(frame,"Successfully created an account. \n You can now Login.","Register Successful",JOptionPane.PLAIN_MESSAGE);
					}
					catch (Exception e) 
					{
						e.printStackTrace();
						regSuccess.setText("<html>Something went wrong while creating an account<br/>" + e.getMessage()	+ "</html>");
						JOptionPane.showMessageDialog(frame,"Username Already Exists\n Try A Differnt Username.","Account create Error",JOptionPane.ERROR_MESSAGE);
					}

				}

			}
		});
		btnRegister.setBounds(290, 126, 241, 76);
		LoginPanel.add(btnRegister);

		JLabel label = new JLabel("Username");			
		label.setFont(new Font("Microsoft JhengHei UI", Font.PLAIN, 13));
		label.setBounds(290, 57, 72, 14);
		LoginPanel.add(label);

		JLabel lblNewUser = new JLabel("Login");
		lblNewUser.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 20));
		lblNewUser.setBounds(21, 15, 231, 31);
		LoginPanel.add(lblNewUser);

		regSuccess.setBounds(290, 147, 241, 55);
		LoginPanel.add(regSuccess);

		loginFail.setBounds(21, 147, 231, 58);
		LoginPanel.add(loginFail);
		
				pwd_reg = new JPasswordField();
				pwd_reg.setFont(new Font("Tahoma", Font.PLAIN, 15));
				pwd_reg.setEchoChar('*');
				pwd_reg.setBounds(371, 85, 160, 20);
				LoginPanel.add(pwd_reg);
		
		JLabel lblRegister = new JLabel("New Users");
		lblRegister.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 20));
		lblRegister.setBounds(290, 12, 228, 31);
		LoginPanel.add(lblRegister);

		panel_1.add(homePanel, "name_48671359027384");
		homePanel.setLayout(null);

		JButton btnNewButton = new JButton("<html>Text Analyzer </html>");    //Text analyzer Function Button 
		btnNewButton.setBounds(128, 54, 272, 116);
		homePanel.add(btnNewButton);
		btnNewButton.addActionListener(new ActionListener() 				//Text analyzer action
		{
			public void actionPerformed(ActionEvent arg0) 
			{

				EventQueue.invokeLater(new Runnable()
				 {
					public void run() 
					{
						try
						 {
							TextAnalyserModule frame = new TextAnalyserModule();
							frame.setVisible(true);
						 }
						catch (Exception e) 
						{
							e.printStackTrace();
						}
					}
				});

			}
		 } );
		
		
		btnNewButton.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 14));
		welcomemsg.setBounds(26, 29, 401, 14);
		homePanel.add(welcomemsg);

		JButton btnNewButton_2 = new JButton("Logout");									//Logout Function Button
		btnNewButton_2.setFont(new Font("Microsoft JhengHei UI", Font.BOLD, 12));
		btnNewButton_2.addActionListener(new ActionListener() 							//Logout action
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				homePanel.setVisible(false);
				LoginPanel.setVisible(true);
				regSuccess.setText("");
				loginFail.setText("");
			}
		});
		btnNewButton_2.setBounds(437, 20, 89, 23);
		homePanel.add(btnNewButton_2);
		
		JPanel Logopanel = new JPanel();
		Logopanel.setBounds(39, 11, 529, 112);
		contentPane.add(Logopanel);
		Logopanel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon(LoginModule.class.getResource("/emotion.png")));
		lblNewLabel.setBounds(10, 11, 245, 101);
		Logopanel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon(LoginModule.class.getResource("/logowin.png")));
		lblNewLabel_1.setBounds(322, 0, 221, 112);
		Logopanel.add(lblNewLabel_1);
		
		
	}
	
}