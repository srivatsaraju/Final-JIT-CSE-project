package com.jit.emotionfinder.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

//This class is used for handling XML property files.
public class XMLUtility
{
	
	//1.Initialization
	private Properties props;	
	private File file;
	
	// Class constructor that loads properties from XML file.
	public XMLUtility(String fileName) 
	{
		props = new Properties();
		try 
		{
			props.loadFromXML(this.getClass().getResourceAsStream(fileName));
		}  catch (IOException e) 
		{
			props = new Properties();
			e.printStackTrace();
		}
	}
	
	//Property getter for String properties.
	public String getProperty(String key) 
	{
		return props.getProperty(key);
	}
	
	// Property getter for int properties.
	public int getIntProperty(String key) 
	{
		return Integer.parseInt(props.getProperty(key));
	}
	
	//  Property getter for array of ints properties.
	public int[] getIntArrayProperty(String key) 
	{
		String line = props.getProperty(key);
		String[] strings = line.split(", ");
		int[] value = new int[strings.length];
		for (int i = 0; i < value.length; i++) 
		{
			value[i] = Integer.parseInt(strings[i], 16);
		}
		return value;
	}
	
	// Property getter for boolean properties.
	public boolean getBooleanProperty(String key) 
	{
		return Boolean.parseBoolean(props.getProperty(key));
	}

	//Property getter for long properties.
	public long getLongProperty(String key) 
	{
		return Long.parseLong(props.getProperty(key));
	}

	// Puts an object into properties.
	public void put(Object key, Object value) 
	{
		props.put(key, String.valueOf(value));
	}
	
	// Stores properties to XML property file.
	public void save()
	{
		try 
		{
			props.storeToXML(new FileOutputStream(file), null);
		}
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();
		}
		catch (IOException e) 
		{
			e.printStackTrace();
		}	
	}
}