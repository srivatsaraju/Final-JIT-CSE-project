package com.jit.emotionfinder.util;

import java.text.BreakIterator;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

//This class is for 
public class ParsingUtility
{

	//1.Parse paragraph into sentences
	public static ArrayList<String> parseSentences(String text) 
	{
		ArrayList<String> value = new ArrayList<String>();

		BreakIterator boundary = BreakIterator.getSentenceInstance();
		boundary.setText(text);
		int start = boundary.first();
		for (int end = boundary.next(); end != BreakIterator.DONE; start = end, end = boundary.next()) 
		{
			String word = text.substring(start, end);
			value.add(word);
		}
		return value;
	}

	//2.Parse sentence into words
	public static ArrayList<String> parseWords(String text) 
	{
		ArrayList<String> value = new ArrayList<String>();

		BreakIterator boundary = BreakIterator.getWordInstance();
		boundary.setText(text);
		int start = boundary.first();
		for (int end = boundary.next(); end != BreakIterator.DONE; start = end, end = boundary.next()) 
		{
			String word = text.substring(start, end);
			value.add(word);
		}
		return value;
	}

	//3.parse words into letters
	public static List<String> splitWords(String text, String splitter) 
	{
		return Arrays.asList(text.split(splitter));
	}
}