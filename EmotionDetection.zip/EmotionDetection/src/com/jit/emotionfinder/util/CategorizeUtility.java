package com.jit.emotionfinder.util;

import com.jit.emotionfinder.textanalysis.EmotionalState;
//this utility class is used to categorize into positive,negative or neutral
public class CategorizeUtility 
{
	public static String findCategory(EmotionalState emotionalState) 
	{
		String status = "";
		try 
		{
			double happy = emotionalState.getHappinessWeight();
			double sad = emotionalState.getSadnessWeight();
			double anger = emotionalState.getAngerWeight();
			double disgust = emotionalState.getDisgustWeight();
			double fear = emotionalState.getFearWeight();
			double surprise = emotionalState.getSurpriseWeight();
			double valence = emotionalState.getValence();
			double pos=happy+surprise;
			double neg=sad+anger;
			double neu=disgust+fear;
			if (happy==sad && happy==surprise && happy==anger && happy==fear &&  happy==disgust)
				status="neutral";
			else if (valence > 0) 
				{
				if (happy==sad && happy==surprise)
					status = "positive";	
				if((pos > neg) || (pos > neu))
					status = "positive";
				if(pos>50) 
					status = "positive";
			    } 
			else if (valence < 0) 
				{
				if((surprise>happy && surprise>35)) 
					status = "negative";
				if (happy==sad && happy==anger) 
					status = "negative";
				if((neg > pos)|| (neg > neu))
					status = "negative";				
				if(neg>50) 
					status = "negative";
				}				
			else status = "neutral";			   
		}
		catch (Exception e) 
		{
			return "neutral";
		}
		return status;
	}
}