package com.jit.emotionfinder.util;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.jit.emotionfinder.util.DirectoryUtility;

import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;

//this utility class is used to create a directory UI with spaces for positive,negative and neutral files along with its count.
@SuppressWarnings("serial")
public class DirectoryUtility extends JFrame 
{

	private JPanel contentPane;
	public JTextArea positive = new JTextArea();

	public JTextArea negative = new JTextArea();

	public JTextArea neutral = new JTextArea();
	public JLabel cpos = new JLabel("");

	public JLabel cneg = new JLabel("");
	public JLabel cneutral = new JLabel("");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) 
	{
		EventQueue.invokeLater(new Runnable() 
		{
			public void run() 
			{
				try 
				{
					DirectoryUtility frame = new DirectoryUtility();
					frame.setVisible(true);
				}
				catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public DirectoryUtility() 
	{
		setTitle("Directory Analyser Result");
		// setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		setBounds(100, 100, 850, 620);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 51, 51));
		panel.setBounds(0, 0, 839, 582);
		contentPane.add(panel);
		panel.setLayout(null);

		JLabel lblDirectoryInputResults = new JLabel("Directory Analyser results are as follows");
		lblDirectoryInputResults.setForeground(new Color(255, 255, 255));
		lblDirectoryInputResults.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblDirectoryInputResults.setBounds(282, 11, 361, 14);
		panel.add(lblDirectoryInputResults);

		JLabel lblCategoryPositive = new JLabel("Category: Positive");
		lblCategoryPositive.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblCategoryPositive.setForeground(new Color(255, 255, 255));
		lblCategoryPositive.setBounds(44, 42, 140, 14);
		panel.add(lblCategoryPositive);

		JLabel lblCategoryNegative = new JLabel("Category: Negative");
		lblCategoryNegative.setForeground(Color.WHITE);
		lblCategoryNegative.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblCategoryNegative.setBounds(300, 42, 140, 14);
		panel.add(lblCategoryNegative);

		JLabel lblCategoryNeutral = new JLabel("Category: Neutral");
		lblCategoryNeutral.setForeground(Color.WHITE);
		lblCategoryNeutral.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblCategoryNeutral.setBounds(560, 42, 129, 14);
		panel.add(lblCategoryNeutral);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(44, 73, 219, 470);
		panel.add(scrollPane);

		positive.setForeground(new Color(0, 0, 204));
		scrollPane.setViewportView(positive);

		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(300, 73, 219, 470);
		panel.add(scrollPane_1);
		negative.setForeground(new Color(204, 102, 0));
		scrollPane_1.setViewportView(negative);

		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(560, 73, 219, 470);
		panel.add(scrollPane_2);
		scrollPane_2.setViewportView(neutral);
		
		cpos.setFont(new Font("Verdana", Font.BOLD, 11));
		cpos.setForeground(Color.WHITE);
		cpos.setBounds(163, 42, 63, 14);
		panel.add(cpos);

		cneg.setForeground(Color.WHITE);
		cneg.setFont(new Font("Verdana", Font.BOLD, 11));
		cneg.setBounds(422, 42, 63, 14);
		panel.add(cneg);
		cneutral.setForeground(Color.WHITE);
		cneutral.setFont(new Font("Verdana", Font.BOLD, 11));
		cneutral.setBounds(673, 42, 63, 14);
		panel.add(cneutral);
	}
}