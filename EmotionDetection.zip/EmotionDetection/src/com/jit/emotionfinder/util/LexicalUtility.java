package com.jit.emotionfinder.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import com.jit.emotionfinder.textanalysis.AffectWord;
import com.jit.emotionfinder.util.LexicalUtility;
import com.jit.emotionfinder.util.ParsingUtility;
import com.jit.emotionfinder.util.XMLUtility;

//This class 
public class LexicalUtility 
{
	
	//1.initialization
	private String fileNameLexicon = "/data/lex/ontology.txt";
	private String fileNameEmoticons = "/data/lex/emoticons.txt";
	private String fileNameProperties = "/data/lex/keywords.xml";	
	private List<AffectWord> affectWords;
	private List<AffectWord> emoticons;
	private List<String> negations;
	private List<String> intensityModifiers;
	private double normalisator = 1;
	private static LexicalUtility instance;
	
	//2.Returns the Singleton instance of the LexicalUtility.
		public static LexicalUtility getInstance() throws IOException 
		{
			if (instance == null) 
			{
				instance = new LexicalUtility();
			}
			return instance;
		}
		
	//3 negation function
		public boolean isNegation(String word) 
		{
			return negations.contains(word);
		}

	//4 modifier function
		public boolean isIntensityModifier(String word) 
		{
		return intensityModifiers.contains(word);
		}

	//5 check if negation is part of the same sentence
		public static boolean inTheSamePartOfTheSentence(String negation, String word, String sentence) 
		{
			int i = sentence.indexOf(negation);
			int j = sentence.indexOf(word);
			if (i < j) 
			{
				i += negation.length();
			} 
			else 
			{
				int tmp = i;
				i = j + word.length();
				j = tmp;
			}
			for (int k = i; k < j; k++) 
			{
				if ((sentence.charAt(k) == ',') ||(sentence.charAt(k) == '.') ||(sentence.charAt(k) == ';') 
					||(sentence.charAt(k) == ':') ||(sentence.charAt(k) == '-')) 
				{
					return false;
				}
			}
			return true;
		}
		
	//6.main function
	private LexicalUtility() throws IOException
	{
		affectWords = new ArrayList<AffectWord>();
		emoticons = new ArrayList<AffectWord>();
		XMLUtility pm = new XMLUtility(fileNameProperties);
		negations = ParsingUtility.splitWords(pm.getProperty("negations"), ", ");
		intensityModifiers = ParsingUtility.splitWords(pm.getProperty("intensity.modifiers"), ", ");
		parseLexiconFile(affectWords, fileNameLexicon);
		parseLexiconFile(emoticons, fileNameEmoticons);
	}	

	//7.function to parse lexicon file
	private void parseLexiconFile(List<AffectWord> wordList, String fileName)
	throws IOException 
	{		
		BufferedReader in = new BufferedReader(new InputStreamReader(this.getClass().getResourceAsStream(fileName), "UTF8"));
		String line = in.readLine();
		while (line != null) 
		{
			AffectWord record = parseLine(line);
			wordList.add(record);
			line = in.readLine();
		}
		in.close();
	}

	//8.function to parse line by line
	private AffectWord parseLine(String line) 
	{
		AffectWord value;
		String[] text = line.split(" ");
		String word = text[0];
		double generalWeight = Double.parseDouble(text[1]);
		double happinessWeight = Double.parseDouble(text[2]);
		double sadnessWeight = Double.parseDouble(text[3]);
		double angerWeight = Double.parseDouble(text[4]);
		double fearWeight = Double.parseDouble(text[5]);
		double disgustWeight = Double.parseDouble(text[6]);
		double surpriseWeight = Double.parseDouble(text[7]);
		value = new AffectWord(word, generalWeight, happinessWeight,
				sadnessWeight, angerWeight, fearWeight, disgustWeight,
				surpriseWeight, normalisator);
		return value;
	}

	//9 Returns the instance of AffectWord for the given word.
	public AffectWord getAffectWord(String word) 
	{
		for (AffectWord AffectWord : affectWords) 
		{
			if (AffectWord.getWord().equals(word)) 
			{
				return AffectWord.clone();
			}
		}
		return null;
	}

	//10.Returns the instance of AffectWord for the given word, which is emoticon.
	public AffectWord getEmoticonAffectWord(String word) 
	{
		for (AffectWord affectWordEmoticon : emoticons) 
		{
			if (affectWordEmoticon.getWord().equals(word)) 
			{
				return affectWordEmoticon.clone();
			}
		}
		for (AffectWord affectWordEmoticon : emoticons) 
		{
			String emoticon = affectWordEmoticon.getWord();
			if (SecondcontainsFirst(word, emoticon)) 
			{
				affectWordEmoticon.setStartsWithEmoticon(true);
				return affectWordEmoticon.clone();
			}
		}
		return null;
	}
	
	//11.Returns true if the fist word begins with the second.
	public static boolean SecondcontainsFirst(String container, String containee) 
	{
		if (container.length() > containee.length()) 
		{
			for (int i = 0; i < containee.length(); i++) 
			{
				if (!(containee.charAt(i) == container.charAt(i))) 
				{
					return false;
				}
			}
			return true;
		} 
		else
		{
			return false;
		}
	}

	//12.Returns all instances of AffectWord which represent emoticons for the given sentence.
	public List<AffectWord> getEmoticonWords(String sentence) 
	{
		List<AffectWord> value = new ArrayList<AffectWord>();
		for (AffectWord emoticon : emoticons) 
		{
			String affectWordEmoticon = emoticon.getWord();
			if (sentence.contains(affectWordEmoticon)) 
			{
				emoticon.setStartsWithEmoticon(true);
				value.add(emoticon);
			}
		}
		return value;
	}
}