package com.jit.emotionfinder.util;

import java.io.IOException;

import com.jit.emotionfinder.textanalysis.AffectWord;
import com.jit.emotionfinder.util.LexicalUtility;

//this utility class is used for defining some rules which is used in the EmotionAlgorithm class.
public class HeuristicsUtility 
{

	//1.compute Emoticon Coefficient based on the word.
	public static double computeEmoticonCoef(String word, AffectWord emoticon) 
	{
		if (emoticon.startsWithEmoticon()) 
		{
			String emotiveWord = emoticon.getWord();
			 double x= 1.0 + (0.2 * countChars(word, emotiveWord.charAt(emotiveWord.length() - 1)));
			if(x>2) x=2.0;
			return x;
		}
		else 
		{
			return 1.0;
		}
	}
	
	//2.Computes the upper case qoeficient based on the word.
		public static double computeCapsLockQoef(String word) 
		{
			if (isCapsLock(word))
				return 2.0;
			else
				return 1.0;
		}
		
	//3.Check the upper case qoeficient based on the word.
		private static boolean isCapsLock(String word) 
		{
			for (int i = 0; i < word.length(); i++) 
			{
				if (Character.isLowerCase(word.charAt(i)))
					return false;
			}
			return true;
		}
		
	//4.Computes the exclamination qoef based on the word.
		public static double computeExclaminationQoef(String text) 
		{		
			double x= 1.0 + (0.2 * countChars(text, '!'));
			if(x>2) x=2;
			return x;
		}
		
	//5.Computes the question mark exclamination qoef based on the word.
		public static boolean hasExclaminationQuestionMarks(String text) 
		{
			if ((text.contains("?!")) || (text.contains("!?")))
				return true; 
			return false;
		}
		
	//6.Computes the intensity modifier based on the word.
	public static double computeModifier(String word) throws IOException 
	{
		if (isIntensityModifier(word))
			return 2.0;
		else
			return 1.0;
	}
	
	//7.Check the intensity modifier based on the word.
		private static boolean isIntensityModifier(String word) throws IOException 
		{
		return LexicalUtility.getInstance().isIntensityModifier(word);
		}			
		

	//8.Returns true if sentence has negation in it.
		public static boolean isNegation(String sentence) throws IOException 
		{
			return LexicalUtility.getInstance().isNegation(sentence);
		}		
		
		
	//9.count number of characters based on word
		private static int countChars(String arg, char c) 
		{
			int count = 0;
			for (int i = 0; i < arg.length(); i++) 
			{
			if (arg.charAt(i) == c)
				count++;
			}
			return count;
		}
}