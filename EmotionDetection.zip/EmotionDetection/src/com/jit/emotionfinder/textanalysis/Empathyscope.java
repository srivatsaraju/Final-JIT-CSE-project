package com.jit.emotionfinder.textanalysis;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;

import com.jit.emotionfinder.util.HeuristicsUtility;
import com.jit.emotionfinder.util.LexicalUtility;
import com.jit.emotionfinder.util.ParsingUtility;
import com.jit.emotionfinder.textanalysis.AffectWord;
import com.jit.emotionfinder.textanalysis.Emotion;
import com.jit.emotionfinder.textanalysis.EmotionalState;

//This class is the implementation of the emotion recognition algorithm
public class Empathyscope 
{	
	
	public  static double temp1;
	public  static double temp2;
	public  static double temp3;
	public  static double temp4;
	public  static double temp5;
	public  static double temp6;

	//This function is used to implement the 3 word level rules and 3 sentence level rules
	public static EmotionalState feel(String text) throws IOException 
	{		
		
		//1.Initialization
		temp1=0.0;
		temp2=0.0;
		temp3=0.0;
		temp4=0.0;
		temp5=0.0;
		temp6=0.0;
		
		LexicalUtility lexUtil = LexicalUtility.getInstance();
		
		//2.Replace new line characters with spaces
		text = text.replace('\n', ' ');
		
		//3.Create a array list of all words
		List<AffectWord> affectWords = new ArrayList<AffectWord>();
		
		//4.Parse paragraph input to sentences
		List<String> sentences = ParsingUtility.parseSentences(text);
		for (String sentence : sentences) {
		System.out.println("- " + sentence);
		
		//5.Sentence level rule 1 ExQ
			double exclaminationQoef = HeuristicsUtility.computeExclaminationQoef(sentence.toLowerCase());
		
		//6.Sentence level rule 2 QUExQ		
			if (HeuristicsUtility.hasExclaminationQuestionMarks(sentence)) 
			{
				AffectWord emoWordSurprise = new AffectWord("?!");
				emoWordSurprise.setSurpriseWeight(1.0);
				affectWords.add(emoWordSurprise);
			}
		
		//7.Sentence level rule 3 Negation Rule
			boolean hasNegation = false;
		
		//8 Parse sentence input to words
			List<String> splittedWords = ParsingUtility.splitWords(sentence, " ");
			String previousWord = "";
			String negation = "";

		
			//9 Word level rule 1
			    for (String splittedWord : splittedWords) 
			    {
				AffectWord emoWord = lexUtil.getAffectWord(splittedWord);
				if (emoWord == null)
					emoWord = lexUtil.getEmoticonAffectWord(splittedWord.toLowerCase());				
				if (emoWord != null) 
				{
				double emoticonCoef = HeuristicsUtility.computeEmoticonCoef(splittedWord, emoWord);
				if (emoticonCoef == 1.0)
					emoticonCoef = HeuristicsUtility.computeEmoticonCoef(splittedWord.toLowerCase(), emoWord);
					emoWord.adjustWeights(exclaminationQoef * emoticonCoef);
					affectWords.add(emoWord);
				}
				else 
				{
					List<String> words = ParsingUtility.parseWords(splittedWord);
		
				//10 Word level rule 2 & 3
				for (String word : words) 
				{
					if (HeuristicsUtility.isNegation(word.toLowerCase())) 
					{
					negation = word;
					hasNegation = true;
					}
						emoWord = lexUtil.getAffectWord(word.toLowerCase());
						if (emoWord == null)
							emoWord = lexUtil.getAffectWord(word.toLowerCase());
						if (emoWord != null) 
						{
							double capsLockCoef = HeuristicsUtility.computeCapsLockQoef(word);
							double modifierCoef = HeuristicsUtility.computeModifier(previousWord);
							if ((hasNegation) && (LexicalUtility.inTheSamePartOfTheSentence(negation, emoWord.getWord(),sentence))) 
							{
								emoWord.flipValence();
							}
							emoWord.adjustWeights(exclaminationQoef * capsLockCoef * modifierCoef );
							affectWords.add(emoWord);
						}
						previousWord = word;
					}
				}
			}
		}
		return createEmotionalState(text, affectWords);

	}

	//This function creates a emotional state
	private static EmotionalState createEmotionalState(String text, List<AffectWord> AffectWords) 
	{
		//1.Initialization
		TreeSet<Emotion> emotions = new TreeSet<Emotion>();
		int generalValence = 0;
		double valence, generalWeight, happinessWeight, sadnessWeight, angerWeight, fearWeight, disgustWeight,surpriseWeight;
		valence = 0.0;
		generalWeight = 0.0;
		happinessWeight = 0.0;
		sadnessWeight = 0.0;
		angerWeight = 0.0;
		fearWeight = 0.0;
		disgustWeight = 0.0;
		surpriseWeight = 0.0;
		for (AffectWord AffectWord : AffectWords) 
		{
			valence += AffectWord.getGeneralValence();
			if (AffectWord.getGeneralWeight() > generalWeight)
				generalWeight = AffectWord.getGeneralWeight();
			if (AffectWord.getHappinessWeight() > happinessWeight)
				happinessWeight = AffectWord.getHappinessWeight();
				temp1=Math.round(happinessWeight*100.0)/100.0;
			if (AffectWord.getSadnessWeight() > sadnessWeight)
				sadnessWeight = AffectWord.getSadnessWeight();
				temp2=Math.round(sadnessWeight*100.0)/100.0;
			if (AffectWord.getAngerWeight() > angerWeight)
				angerWeight = AffectWord.getAngerWeight();
				temp3=Math.round(angerWeight*100.0)/100.0;
			if (AffectWord.getFearWeight() > fearWeight)
				fearWeight = AffectWord.getFearWeight();
				temp4=Math.round(fearWeight*100.0)/100.0;
			if (AffectWord.getDisgustWeight() > disgustWeight)
				disgustWeight = AffectWord.getDisgustWeight();
				temp5=Math.round(disgustWeight*100.0)/100.0;
			if (AffectWord.getSurpriseWeight() > surpriseWeight)
				surpriseWeight = AffectWord.getSurpriseWeight();
				temp6=Math.round(surpriseWeight*100.0)/100.0;
				
		}
		//2.Categorize into positive or negative based on valence
		if (valence > 0)
			generalValence = 1;
		else if (valence < 0)
			generalValence = -1;
		
		//3.print value on console
		System.out.println("General weight .. " + generalWeight);
		System.out.println("happiness weight .. " + happinessWeight);
		System.out.println("sadness weight .. " + sadnessWeight);
		System.out.println("fear weight .. " + fearWeight);
		System.out.println("disgust weight .. " + disgustWeight);
		System.out.println("ngry weight .. " + angerWeight);
		System.out.println("surprise weight .. " + surpriseWeight);
		
		//4.Convert weight to percentage value
		happinessWeight = (happinessWeight / generalWeight) * 100;
		sadnessWeight = (sadnessWeight / generalWeight) * 100;
		angerWeight = (angerWeight / generalWeight) * 100;
		fearWeight = (fearWeight / generalWeight) * 100;
		disgustWeight = (disgustWeight / generalWeight) * 100;
		surpriseWeight = (surpriseWeight / generalWeight) * 100;
		double total = happinessWeight + sadnessWeight + angerWeight + fearWeight + disgustWeight + surpriseWeight;
		happinessWeight = (happinessWeight / total) * 100;
		sadnessWeight = (sadnessWeight / total) * 100;
		angerWeight = (angerWeight / total) * 100;
		fearWeight = (fearWeight / total) * 100;
		disgustWeight = (disgustWeight / total) * 100;
		surpriseWeight = (surpriseWeight / total) * 100;
		
		//5.Round percentage values		
		happinessWeight = Math.round(happinessWeight*100.0)/100.0;
		sadnessWeight = Math.round(sadnessWeight*100.0)/100.0;
		angerWeight = Math.round(angerWeight*100.0)/100.0;
		fearWeight = Math.round(fearWeight*100.0)/100.0;
		disgustWeight = Math.round(disgustWeight*100.0)/100.0;		
		surpriseWeight = Math.round(surpriseWeight*100.0)/100.0;

		//6.add values to emotions set
		if (happinessWeight > 0)
			emotions.add(new Emotion(happinessWeight, Emotion.HAPPINESS));
		if (sadnessWeight > 0)
			emotions.add(new Emotion(sadnessWeight, Emotion.SADNESS));
		if (angerWeight > 0)
			emotions.add(new Emotion(angerWeight, Emotion.ANGER));
		if (fearWeight > 0)
			emotions.add(new Emotion(fearWeight, Emotion.FEAR));
		if (disgustWeight > 0)
			emotions.add(new Emotion(disgustWeight, Emotion.DISGUST));
		if (surpriseWeight > 0)
			emotions.add(new Emotion(surpriseWeight, Emotion.SURPRISE));
		
		//7.return final emotional state
		return new EmotionalState(text, emotions, generalWeight, generalValence);
	}
}