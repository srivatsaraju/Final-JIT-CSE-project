package com.jit.emotionfinder.textanalysis;
//This class represents one unit from the lexicon i.e a word associated with emotional meaning and it's emotional weights and valence

import com.jit.emotionfinder.textanalysis.AffectWord;

public class AffectWord
{
	//1.initialization
	private String word;
	private double generalWeight = 0.0;
	private double generalValence = 0.0;
	private double happinessWeight = 0.0;
	private double sadnessWeight = 0.0;
	private double angerWeight = 0.0;
	private double fearWeight = 0.0;
	private double disgustWeight = 0.0;
	private double surpriseWeight = 0.0;
	private boolean startsWithEmoticon = false;

	//2. Class constructor-1 which sets the AffectWord
	  public AffectWord(String word)
	  {
			this.word = word;
	  }

	//3. Class constructor-2 which sets the AffectWord and it's weights.
		public AffectWord(String word,
				double generalWeight,
				double happinessWeight, 
				double sadnessWeight,
				double angerWeight,
				double fearWeight,
				double disgustWeight,
				double surpriseWeight)
		{
			this.word = word;
			this.generalWeight = generalWeight;
			this.happinessWeight = happinessWeight;
			this.sadnessWeight = sadnessWeight;
			this.angerWeight = angerWeight;
			this.fearWeight = fearWeight;
			this.disgustWeight = disgustWeight;
			this.surpriseWeight = surpriseWeight;
			this.generalValence = getValenceSum();
		}

	//4. Class constructor which sets the AffectWord and it's weights, adjusted by the quoeficient.
		public AffectWord(String word,
				double generalWeight,
				double happinessWeight, 
				double sadnessWeight, 
				double angerWeight,
				double fearWeight, 
				double disgustWeight, 
				double surpriseWeight,
				double quoficient)
		{
			this.word = word;
			this.generalWeight = generalWeight * quoficient ;
			this.happinessWeight = happinessWeight * quoficient ;
			this.sadnessWeight = sadnessWeight * quoficient ;
			this.angerWeight = angerWeight * quoficient ;
			this.fearWeight = fearWeight * quoficient ;
			this.disgustWeight = disgustWeight * quoficient ;
			this.surpriseWeight = surpriseWeight * quoficient ;
			this.generalValence = getValenceSum();
		}

	//5. Adjusts weights by the certain quoficient.
		public void adjustWeights(double quoficient) 
		{
			this.generalWeight = generalWeight * quoficient ;
			
			if(happinessWeight > 0.5)
			this.happinessWeight = happinessWeight * quoficient ;
			
			if(sadnessWeight > 0.5)
			this.sadnessWeight = sadnessWeight * quoficient ;
			
			if(angerWeight > 0.5)
			this.angerWeight = angerWeight * quoficient ;
			
			if(fearWeight > 0.5)
			this.fearWeight = fearWeight * quoficient ;
			
			if(disgustWeight > 0.5)
			this.disgustWeight = disgustWeight * quoficient ;
			
			if(surpriseWeight > 0.5)
			this.surpriseWeight = surpriseWeight * quoficient ;
		}
		

    //6.Flips valence of the word -- calculates change from postive to negative emotion.
		public void flipValence() 
		{
			generalValence = -generalValence;
			double temp = happinessWeight;
			happinessWeight = Math.max(Math.max(sadnessWeight, angerWeight), Math.max(fearWeight, disgustWeight));
			sadnessWeight = temp;
			angerWeight = temp / 2;
			fearWeight = temp / 2;
			disgustWeight = temp / 2;
		}

	//7.Makes duplicate of the object.
		public AffectWord clone()
		{
			AffectWord value = new AffectWord(word, generalWeight, happinessWeight, sadnessWeight, angerWeight, fearWeight, disgustWeight, surpriseWeight);
			value.setStartsWithEmoticon(startsWithEmoticon);
			return value;
		}

	//8.Returns true if the word starts with the emoticon.
		public boolean startsWithEmoticon() 
		{
			return startsWithEmoticon;
		}

	//9.Sets does the word start with emoticon.
		public void setStartsWithEmoticon(boolean startsWithEmoticon) 
		{
			this.startsWithEmoticon = startsWithEmoticon;
		}
	

		//10.Getter for the word 
		public String getWord() 
		{
			return word;
		}
		//11.Getter for the valence sum.
		private double getValenceSum() 
		{
			return happinessWeight - sadnessWeight - angerWeight - fearWeight
					- disgustWeight;
		}	
		//12.Getter & Setter for the general valence.
		public double getGeneralValence() 
		{
			return generalValence;
		}
		//13.Getter & Setter for the general weight.
		public double getGeneralWeight() 
		{
			return generalWeight;
		}		
			//14.Getter & Setter for the happiness weight.
		public double getHappinessWeight() 
		{
			return happinessWeight;
		}
		
			//15.Getter & Setter for the sadness weight.
		public double getSadnessWeight() 
		{
		return sadnessWeight;
		}
			
			//16.Getter & Setter for the anger weight.
		public double getAngerWeight() 
		{
		return angerWeight;
		}
			//17.Getter & Setter for the fear weight.
		public double getFearWeight() 	
		{
		return fearWeight;
		}
			//18.Getter & Setter for the disgust weight.
		public double getDisgustWeight() 
		{
		return disgustWeight;
		}
			//19.Getter & Setter for the surprise weight.
		public double getSurpriseWeight() 
		{
		return surpriseWeight;
		}
		public void setSurpriseWeight(double surpriseWeight) 
		{
		this.surpriseWeight = surpriseWeight;
		}
	
	//20.Returns a string representation of the object.
	public String toString() 
	{
		return word + " " + generalWeight + " " + happinessWeight + " "	+ sadnessWeight + " " + angerWeight + " " + fearWeight + " " + disgustWeight + " " + surpriseWeight;
	}
	
}