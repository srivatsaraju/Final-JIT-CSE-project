package com.jit.emotionfinder.textanalysis;

import com.jit.emotionfinder.textanalysis.Emotion;

//This class represents one emotion, with it's type and weight.

public class Emotion implements Comparable<Emotion> {
	//1.Initialization
	public static int NEUTRAL = -1;
	public static int HAPPINESS = 0;
	public static int SADNESS = 1;
	public static int FEAR = 2;
	public static int ANGER = 3;
	public static int DISGUST = 4;
	public static int SURPRISE = 5;
	protected String text;
	private double weight;
	private int type;	

	//2.Class constructor-1 which sets weight and type of the emotion.
	public Emotion(double weight, int type) 
	{
		this.weight = weight;
		this.type = type;
	}
	
	//3.Class constructor-2 which sets text
	public Emotion(String text) 
	{
		this.text = text;
	}

	//4.Compares weights of current object and the one from the argument.
	public int compareTo(Emotion arg0) 
	{
		int value = (int) (100 * (arg0.getWeight() - weight));
		if (value == 0)
		return 1;
		return value;
	}

	//5.Getter for the emotion type & emotional weight
	public int getType() 
	{
		return type;
	}
	public double getWeight() 
	{
		return weight;
	}
	
	//7.Returns a string representation of the object.
	public String toString() 
	{
		return "Type number: " + type + ", weight: " + weight;
	}	
}