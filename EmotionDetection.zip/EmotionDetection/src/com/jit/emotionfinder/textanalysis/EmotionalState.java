package com.jit.emotionfinder.textanalysis;

import java.util.ArrayList;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;

import com.jit.emotionfinder.textanalysis.Emotion;

//This class defines emotional content of the text.

public class EmotionalState extends Emotion 
{
	//1.Initialization
	private double generalWeight = 0.0;
	private int valence = 0;	
	private SortedSet<Emotion> emotions;	
	
	//2. Class constructor-1 which sets the initial text as impression=neutral.
	public EmotionalState(String text) 
	{
		super(text);
		emotions = new TreeSet<Emotion>();
		emotions.add(new Emotion(1.0, Emotion.NEUTRAL));
	}

	//3.Class constructor-2 which sets the text, general emotional weight, emotional valence, and all of the emotional weights 
	public EmotionalState(String text, SortedSet<Emotion> emotions,	double generalWeight, int valence) 
	{
		super(text);
		this.generalWeight = generalWeight;
		this.valence = valence;
		this.emotions = emotions;
	}
	
	//4.Returns several emotions (Emotion instances) with the highest weight.
	public List<Emotion> getFirstStrongestEmotions(int stop) 
	{
		List<Emotion> value = new ArrayList<Emotion>();
		for (Emotion e : emotions) 
		{
			if (stop <= 0) 
			{
				break;
			}
			value.add(e);
			stop--;
		}
		return value;
	}	

	//5.Getter for Valence
	public int getValence() 
	{
		return valence;
	}	

	//6.Getter functions for the Emotion of happiness & weight of happiness
	public Emotion getHappiness() 
	{
		Emotion value = new Emotion(0.0, Emotion.HAPPINESS);
		for (Emotion e : emotions) 
		{
			if (e.getType() == Emotion.HAPPINESS) 
			{
				value = e;
			}
		}
		return value;
	}	
	public double getHappinessWeight() 
	{
		return getHappiness().getWeight();
	}
	
	//7.Getter functions for the Emotion of sadness & weight of sadness
	public Emotion getSadness() 
	{
		Emotion value = new Emotion(0.0, Emotion.SADNESS);
		for (Emotion e : emotions) 
		{
			if (e.getType() == Emotion.SADNESS) 
			{
				value = e;
			}
		}
		return value;
	}
	public double getSadnessWeight() 
	{
		return getSadness().getWeight();
	}
	
	//8.Getter functions for the Emotion of anger & weight of anger
	public Emotion getAnger() 
	{
		Emotion value = new Emotion(0.0, Emotion.ANGER);
		for (Emotion e : emotions) 
		{
			if (e.getType() == Emotion.ANGER) 
			{	
				value = e;
			}
		}
		return value;
	}
	public double getAngerWeight() 
	{
		return getAnger().getWeight();
	}
	
	//9.Getter functions for the Emotion of fear & weight of fear
	public Emotion getFear() 
	{
		Emotion value = new Emotion(0.0, Emotion.FEAR);
		for (Emotion e : emotions) 
		{
			if (e.getType() == Emotion.FEAR) 
			{
				value = e;
			}
		}
		return value;
	}
	public double getFearWeight() 
	{
		return getFear().getWeight();
	}
	
	//10.Getter functions for the Emotion of disgust & weight of disgust
	public Emotion getDisgust() 
	{
		Emotion value = new Emotion(0.0, Emotion.DISGUST);
		for (Emotion e : emotions) 
		{
			if (e.getType() == Emotion.DISGUST) 
			{
				value = e;
			}
		}
		return value;
	}
	public double getDisgustWeight() 
	{
		return getDisgust().getWeight();
	}
	
	//11.Getter functions for the Emotion of surprise & weight of surprise 
	public Emotion getSurprise() 
	{
		Emotion value = new Emotion(0.0, Emotion.SURPRISE);
		for (Emotion e : emotions) 
		{
			if (e.getType() == Emotion.SURPRISE) 
			{
				value = e;
			}
		}
		return value;
	}
	public double getSurpriseWeight() 
	{
		return getSurprise().getWeight();
	}
	
	
	//12.Transforms emotional data into a descriptional sentence 
	public String toString() 
	{
		return "Text: " + text + "\nGeneral weight: " + generalWeight	+ "\nValence: " + valence +
				"\nHappiness weight: "+ getHappinessWeight() + 
				"\nSadness weight: "+ getSadnessWeight() +
				"\nAnger weight: " + getAngerWeight()+
				"\nFear weight: " + getFearWeight() +
				"\nDisgust weight: "+ getDisgustWeight() +
				"\nSurprise weight: "+ getSurpriseWeight() + "\n";
	}

	public String toString(String separator) 
	{
		return text + separator 
		+ generalWeight + separator 
		+ valence + separator
		+ getHappinessWeight() + separator
		+ getSadnessWeight() + separator 
		+ getAngerWeight() + separator 
		+ getFearWeight() + separator
		+ getDisgustWeight() + separator
		+ getSurpriseWeight();
	}
}