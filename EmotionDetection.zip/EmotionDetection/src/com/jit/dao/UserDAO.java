package com.jit.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UserDAO 
{

	public void register(String un, String pw) throws Exception 
	{
		Connection con = null;
		try
		{
			con = MySQLUtil.getConnection();
			PreparedStatement ps = con.prepareStatement("insert into USER values (?,?) ");
			//check the duplicate username--primary key //
			ps.setString(1, un);
			ps.setString(2, pw);
			ps.execute();
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw e;
		}
		finally 
		{
			con.close();
		}

	}

	public boolean login(String un, String pw) throws Exception 
	{
		Connection con = null;
		try 
		{
			con = MySQLUtil.getConnection();
			PreparedStatement ps = con.prepareStatement("select count(*) from USER where username=? and password=? ");
			ps.setString(1, un);
			ps.setString(2, pw);
			ResultSet rs = ps.executeQuery();
			rs.next();
			if (rs.getInt(1) > 0) 
			{
				return true;
			}
			else 
			{
				return false;
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			throw e;
		}
		finally 
		{
			con.close();
		}

	}
}
